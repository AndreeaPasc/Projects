-----------------------
-- John Doe
-- 31.02.2020
-----------------------
-- Edit the lines above with your name and the submission date.

module Solutions exposing (..)

-- deck : List Card
deck = Debug.todo "Implement this"

-- cardValue : Card -> List Card
cardValue card = Debug.todo "Implement this"

smallestK : Int -> List a -> List a
smallestK k list = Debug.todo "Implement this"

balanced : String -> Bool
balanced = Debug.todo "Implement this"

coinChange : Int -> List Int -> Int
coinChange sum coins = Debug.todo "Implement this"